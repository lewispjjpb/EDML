# -*- coding: utf-8 -*-
"""
Created on Thu Sep  5 18:47:18 2019

@author: lewispjjpb

This falls under the general licensing agreement for Github, free to copy, share, and edit.  If you use this as a starting point for something much greater, please give me some credit in your notes :)
Thanks to all the other coders out there who have helped my Elite Dangerous experience, especially the creators of Inara, EDMC, and the Canonn plug-in.
"""

from config import config
import myNotebook as nb
import os
import Tkinter as tk
import sys
import requests
import watchdog
import ttk


def plugin_start(plugin_dir):
   """
   Load this plugin into EDMC
   """
   print("I am loaded! My plugin folder is {}".format(plugin_dir.encode("utf-8")))
   return "EDML"





myPlugin = "EDmissionlogg"




this = sys.modules[__name__]	# For holding module globals

def plugin_prefs(parent, cmdr, is_beta):
   """
   Return a TK Frame for adding to the EDMC settings dialog.
   """
   this.mysetting = tk.IntVar(value=config.getint("MyPluginSetting"))	# Retrieve saved value from config
   frame = nb.Frame(parent)
   nb.Label(frame, text="o7").grid()
   nb.Label(frame, text="Commander!").grid()
   nb.Checkbutton(frame, text="This button does nothing", variable=this.mysetting).grid()

   return frame
   



def prefs_changed(cmdr, is_beta):
   """
   Save settings.
   """
   config.set('MyPluginSetting', this.mysetting.getint())	





def plugin_app(parent):
   """
   Create a pair of TK widgets for the EDMC main window
   """

   def hellocallback():
       tk.messagebox.showinfo( "Hello Python", "Hello World")
   def callback():
       tk.Label(parent, text = 'something, dammit').pack()
############################################################################
   def EDmissionlog():
        import re, csv
        import glob, os
        from datetime import date
        import getpass
        
        #this is whatever your account name is on your computer, needed
        #for the path instructions
        
        username = getpass.getuser()
        
        #loop through directory and find the right files
        
        
        loglist = glob.glob(r'C:\Users\Patrick\Saved Games\Frontier Developments\Elite Dangerous\*.log')
        loglist.sort()
        
        datez = date.today()
        stringdate = datez.strftime('%y' '%m' '%d')
        
        loglist2 = []
        
        for line in loglist:
            if line[len(loglist[0])-19:len(loglist[0])-13] == stringdate:
                loglist2.append(line)
        
        
        loglist2.sort()
        
        outputpath = 'C:\\Users\\' + username + '\\Desktop'
        outputfilename = loglist2[0][len(loglist[0])-19:len(loglist[0])-13] + '.csv'
        output = outputpath + '\\' + outputfilename
        
        fulllog = []
        
        
        for line in loglist2:
            file = open(line, 'r')
            data = file.read()
            file.close()
            data2 = data.split('\n')
            for line in data2:
                line.split('\n')
                fulllog.append(line)
        
        
        fulllog.sort()
        
        
        
        tableofstuff = [
                #bgs
                        'eventtitle',
                        'timestamp',
                        'MissionID',
                        'Faction',
                        'Destinationsystem',
                        'DestinationStation',
                        'creditamount',
                        'materialreward',
                        'influencegain',
                        'reputationgain',
                        'vouchertype',
                        'vouchamount',
                        'nettrade',
                        'commoditytype',
                        'explorationvalue'
                        
                                ]
        
        #fulllog.sort()
        
        
        with open(output, 'w') as fout:
            cout = csv.DictWriter(fout,
                                  tableofstuff,
                                lineterminator = '\n'
            )
            cout.writeheader()
        
        
        
        
        
        
        for line in fulllog:
            event = None
            time = None
            MC = None
            fact = None
            destsys = None
            dest = None
            credz = None
            matz = None
            influ = None
            repu = None
            vouchtype = None
            vouchamount = None
            nettr = None
            commotype = None
            explodata = None
            
            
            event = re.search('(?<="event":)[\S]*,', line)
            if event != None:
                event = event.group()
        
        
            time = re.search('(?<="timestamp":)[\S]*,', line)
            if time != None:
                time = time.group()
        
            MC = re.search('(?<="MissionID":)\d*', line)
            if MC != None:
                MC = MC.group()
        
            fact = re.search('(?<="Faction":)[^,]*', line)
            if fact != None:
                fact = fact.group()
                
            destsys = re.search('(?<="DestinationSystem":)[^,]*', line)
            if destsys != None:
                destsys = destsys.group()        
        
            dest = re.search('(?<="DestinationStation":)[^,]*', line)
            if dest != None:
                dest = dest.group()
        
            credz = re.search('(?<=("Reward":)|("Amount":))\d*', line)
            if credz != None:
                credz = credz.group()
        
            matz = re.search('(?:"MaterialsReward"[\s\S]*, "Name_Localised":")[^,]*', line)
            if matz != None:
                matz = matz.group()
        
            influ = re.search('(?<="Trend":"UpGood", "Influence":")\+*', line)
            if influ != None:
                influ = influ.group()
                
            repu = re.search('(?<="ReputationTrend":"UpGood", "Reputation":")\+*', line)
            if repu != None:
                repu = repu.group()
        
            vouchtype = re.search('(?<="event":"RedeemVoucher", "Type":)[^,]*', line)
            if vouchtype != None:
                vouchtype = vouchtype.group()
        
            nettr = re.search('(?<=("TotalSale":))\d*', line)
            if nettr != None:
                nettr = nettr.group()
                
            commotype = re.search('(?<=("MarketID":[\d]{10}, "Type":))"[^,]*"', line)
            if commotype != None:
                commotype = commotype.group()        
        
            explodata = re.search('(?<=( "TotalEarnings":))\d*', line)
            if explodata != None:
                explodata = explodata.group()
        
        
        
        ### if event title falls within certain list, then create the datatable
        
                
        
            datatable = {
                    'eventtitle': event,
                    'timestamp': time,
                    'MissionID': MC,
                    'Faction': fact,
                    'Destinationsystem': destsys,
                    'DestinationStation': dest,
                    'creditamount': credz,
                    'materialreward': matz,
                    'influencegain': influ,
                    'reputationgain': repu,
                    'vouchertype': vouchtype,
                    'nettrade': nettr,
                    'commoditytype': commotype,
                    'explorationvalue': explodata
                    
                    }
        
        
            importantevents = ['"MissionCompleted",',
                            '"Bounty",',
                            '"CommunityGoalReward",',
                            '"DatalinkVoucher",',
                            '"MarketBuy",',
                            '"MarketSell",',
                            '"MissionAccepted",',
                            '"MissionCompleted",',
                            '"MissionRedirected",',
                            '"PayBounties",',
        #                    '"PowerplaySalary",',
                            '"RedeemVoucher",',
                            '"SearchAndRescue",',
        #                    '"SellDrones",',
                            '"SellExplorationData",'
                            ]
            
            for i in range(len(importantevents)):
            
                if event == importantevents[i]:
                    with open(output, 'a') as fout:
                        cout = csv.DictWriter(fout,
                                          tableofstuff,
                                        lineterminator = '\n'
                                            )
                        cout.writerow(datatable)
                        i + 1
#########################################################




   label = tk.Label(parent, text="Elite Dangerous Mission Log")
   b = tk.Button(parent, text = 'Generate Log', command = EDmissionlog)
   this.status = tk.Label(parent, anchor=tk.W, text="crick button preez")
   return (label, this.status, b)

   
   
def plugin_stop():
    """
    EDMC is closing
    """
    print("Farewell cruel world!")
    
    
